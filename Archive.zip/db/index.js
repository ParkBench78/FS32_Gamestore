module.exports = {
    ...require('./videoGames'),
    ...require('./boardGames')
};